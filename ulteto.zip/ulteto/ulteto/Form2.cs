﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ulteto
{
    public partial class Form2 : Form
    {
        private bool buttonClicked = false;
        private List<string> savedData;
        private List<string> selectedVegetables;

        public Form2(List<string> savedData)
        {
            InitializeComponent();
            this.selectedVegetables = savedData;

            this.Size = new Size(1698, 971);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            numericUpDown1.Minimum = 1;
            numericUpDown1.Maximum = 3;

            foreach (string vegetable in selectedVegetables)
            {
                string firstAndLastLetters = $"{vegetable[0]}{vegetable[vegetable.Length - 1]}";
                listBox1.Items.Add(firstAndLastLetters);
            }

            SetGlassEffect(panel2);

            SetButtonColor(button1, "#99c632");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (buttonClicked)
            {
                MessageBox.Show("Az ágyás létre van hozva!");
                return;
            }

            int numberOfBeds = (int)numericUpDown1.Value;

            if (numberOfBeds <= 0)
            {
                MessageBox.Show("Adjon meg érvényes ágyás számot!");
                return;
            }

            int xpos = int.Parse(comboBox1.Text);
            int ypos = int.Parse(comboBox2.Text);

            int x = 40;
            int y = 228 + (int)(2 * CreateGraphics().DpiY / 2.54f);

            int index = 0;

            for (int i = 0; i < numberOfBeds; i++)
            {
                Panel panel = new Panel();
                panel.Size = new Size(xpos, ypos);
                panel.BackColor = Color.FloralWhite;

                panel.Paint += (s, pe) =>
                {
                    Graphics g = pe.Graphics;
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                    int circleRadius = 10;
                    int circleSpacing = 5; 

                    for (int row = 0; row < ypos / (circleRadius * 2 + circleSpacing); row++)
                    {
                        bool drawCircle = false; 
                        for (int col = 0; col < xpos / (circleRadius * 2 + circleSpacing); col++)
                        {
                            if (drawCircle)
                            {
                                int circleX = col * (circleRadius * 2 + circleSpacing) + circleSpacing;
                                int circleY = row * (circleRadius * 2 + circleSpacing) + circleSpacing;

                                g.FillEllipse(Brushes.Brown, circleX, circleY, circleRadius * 2, circleRadius * 2);

                                if (index < listBox1.Items.Count) 
                                {
                                    string letter = listBox1.Items[index].ToString();
                                    g.DrawString(letter, DefaultFont, Brushes.White, circleX + circleRadius - 5, circleY + circleRadius - 7);
                                    index++;
                                }
                            }
                            drawCircle = !drawCircle; 
                        }
                    }
                };

                panel.Location = new Point(x, y);

                this.Controls.Add(panel);

                x += xpos + 50;
            }

            buttonClicked = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void SetGlassEffect(Panel panel)
        {
            panel.BackColor = Color.Transparent;
            panel.Paint += (sender, e) =>
            {
                using (GraphicsPath path = RoundedRectangle(panel.ClientRectangle, 10)) 
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(150, Color.White)))
                {
                    e.Graphics.FillPath(brush, path);
                }
            };
        }

        private void SetButtonColor(Button button, string hexColor)
        {
            Color color = ColorTranslator.FromHtml(hexColor);
            button.BackColor = color;
        }

        private GraphicsPath RoundedRectangle(Rectangle rectangle, int radius)
        {
            int diameter = radius * 2;
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(rectangle.Location, size);
            GraphicsPath path = new GraphicsPath();

            path.AddArc(arc, 180, 90);

            arc.X = rectangle.Right - diameter;
            path.AddArc(arc, 270, 90);

            arc.Y = rectangle.Bottom - diameter;
            path.AddArc(arc, 0, 90);

            arc.X = rectangle.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }
    }
}
