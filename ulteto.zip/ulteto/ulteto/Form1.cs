﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace ulteto
{
    public partial class Form1 : Form
    {
        private List<string> savedData = new List<string>();
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\david\\Desktop\\ulteto\\ulteto\\bin\\Debug\\NovenyekAdatbazis.accdb;Persist Security Info=False;";
        public static Form1 Instance;

        public Form1()
        {
            InitializeComponent();
            SetGlassEffect(panel1);
            SetButtonColor(button3, "#99c632");
            button1.TabStop = false;

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadPlants();
        }

        private void Datamata()
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Növények";

                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dgv1.DataSource = dataTable;
                    }
                }
            }
        }

        private void SetGlassEffect(Panel panel)
        {
            panel.BackColor = Color.Transparent;
            panel.Paint += (sender, e) =>
            {
                using (GraphicsPath path = RoundedRectangle(panel.ClientRectangle, 10))
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(150, Color.White)))
                {
                    e.Graphics.FillPath(brush, path);
                }
            };
        }

        private void SetButtonColor(Button button, string hexColor)
        {
            Color color = ColorTranslator.FromHtml(hexColor);
            button.BackColor = color;
        }

        private GraphicsPath RoundedRectangle(Rectangle rectangle, int radius)
        {
            int diameter = radius * 2;
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(rectangle.Location, size);
            GraphicsPath path = new GraphicsPath();

            path.AddArc(arc, 180, 90);
            arc.X = rectangle.Right - diameter;

            path.AddArc(arc, 270, 90);
            arc.Y = rectangle.Bottom - diameter;

            path.AddArc(arc, 0, 90);
            arc.X = rectangle.Left;

            path.AddArc(arc, 90, 90);
            path.CloseFigure();

            return path;
        }
        private void LoadPlants()
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT [Faj HU] FROM Növények";

                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                comboBox3.Items.Add(reader["Faj HU"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a növények betöltésekor: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            savedData.AddRange(listBox1.Items.Cast<string>());
            Datamata();

            Form4 form3 = new Form4();
            form3.ShowDialog();

            savedData.Clear();
            listBox1.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (savedData.Count == 0)
            {
                MessageBox.Show("Nincs hozzáadva zöldség az ágyáshoz!");
                return;
            }

            Form2 form = new Form2(savedData);
            form.ShowDialog();

            savedData.Clear();
            listBox1.Items.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int numberOfItems = (int)numericUpDown1.Value;

            if (numberOfItems == 0)
            {
                MessageBox.Show("Adjon meg valós értéket!");
                return;
            }

            if (comboBox3.SelectedIndex == -1)
            {
                MessageBox.Show("Válasszon ki egy zöldséget!");
                return;
            }

            string selectedVegetable = comboBox3.SelectedItem.ToString();
            for (int i = 0; i < numberOfItems; i++)
            {
                string firstAndLastLetters = $"{selectedVegetable.First()}{selectedVegetable.Last()}";
                savedData.Add(firstAndLastLetters);
                listBox1.Items.Add(firstAndLastLetters);
            }
        }
    }
}
