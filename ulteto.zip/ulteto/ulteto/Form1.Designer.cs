﻿namespace ulteto
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.azonosítóDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fajHUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fajtaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sortávDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tőtávDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.növényekBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.novenyekAdatbazisDataSet = new ulteto.NovenyekAdatbazisDataSet();
            this.novenyekAdatbazisDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.növényekTableAdapter = new ulteto.NovenyekAdatbazisDataSetTableAdapters.NövényekTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.nemPasszolTableAdapter1 = new ulteto.NovenyekAdatbazisDataSetTableAdapters.NemPasszolTableAdapter();
            this.label9 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.növényekBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv1
            // 
            this.dgv1.AllowDrop = true;
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToOrderColumns = true;
            this.dgv1.AllowUserToResizeColumns = false;
            this.dgv1.AllowUserToResizeRows = false;
            this.dgv1.AutoGenerateColumns = false;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.azonosítóDataGridViewTextBoxColumn,
            this.fajHUDataGridViewTextBoxColumn,
            this.fajtaDataGridViewTextBoxColumn,
            this.sortávDataGridViewTextBoxColumn,
            this.tőtávDataGridViewTextBoxColumn});
            this.dgv1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgv1.DataSource = this.növényekBindingSource;
            this.dgv1.Location = new System.Drawing.Point(-3, 495);
            this.dgv1.Name = "dgv1";
            this.dgv1.ReadOnly = true;
            this.dgv1.Size = new System.Drawing.Size(10, 10);
            this.dgv1.TabIndex = 0;
            this.dgv1.Visible = false;
            // 
            // azonosítóDataGridViewTextBoxColumn
            // 
            this.azonosítóDataGridViewTextBoxColumn.DataPropertyName = "Azonosító";
            this.azonosítóDataGridViewTextBoxColumn.HeaderText = "Azonosító";
            this.azonosítóDataGridViewTextBoxColumn.Name = "azonosítóDataGridViewTextBoxColumn";
            this.azonosítóDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fajHUDataGridViewTextBoxColumn
            // 
            this.fajHUDataGridViewTextBoxColumn.DataPropertyName = "Faj HU";
            this.fajHUDataGridViewTextBoxColumn.HeaderText = "Faj HU";
            this.fajHUDataGridViewTextBoxColumn.Name = "fajHUDataGridViewTextBoxColumn";
            this.fajHUDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fajtaDataGridViewTextBoxColumn
            // 
            this.fajtaDataGridViewTextBoxColumn.DataPropertyName = "Fajta";
            this.fajtaDataGridViewTextBoxColumn.HeaderText = "Fajta";
            this.fajtaDataGridViewTextBoxColumn.Name = "fajtaDataGridViewTextBoxColumn";
            this.fajtaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sortávDataGridViewTextBoxColumn
            // 
            this.sortávDataGridViewTextBoxColumn.DataPropertyName = "Sortáv";
            this.sortávDataGridViewTextBoxColumn.HeaderText = "Sortáv";
            this.sortávDataGridViewTextBoxColumn.Name = "sortávDataGridViewTextBoxColumn";
            this.sortávDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tőtávDataGridViewTextBoxColumn
            // 
            this.tőtávDataGridViewTextBoxColumn.DataPropertyName = "Tőtáv";
            this.tőtávDataGridViewTextBoxColumn.HeaderText = "Tőtáv";
            this.tőtávDataGridViewTextBoxColumn.Name = "tőtávDataGridViewTextBoxColumn";
            this.tőtávDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // növényekBindingSource
            // 
            this.növényekBindingSource.DataMember = "Növények";
            this.növényekBindingSource.DataSource = this.novenyekAdatbazisDataSet;
            // 
            // novenyekAdatbazisDataSet
            // 
            this.novenyekAdatbazisDataSet.DataSetName = "NovenyekAdatbazisDataSet";
            this.novenyekAdatbazisDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // novenyekAdatbazisDataSetBindingSource
            // 
            this.novenyekAdatbazisDataSetBindingSource.DataSource = this.novenyekAdatbazisDataSet;
            this.novenyekAdatbazisDataSetBindingSource.Position = 0;
            // 
            // növényekTableAdapter
            // 
            this.növényekTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(72, 351);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(206, 35);
            this.button1.TabIndex = 1;
            this.button1.Text = "Tábla betöltése";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(82, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "Adatok megadása";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(72, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 22);
            this.label4.TabIndex = 6;
            this.label4.Text = "Zöldségek";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(76, 88);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(84, 24);
            this.comboBox3.TabIndex = 14;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.SystemColors.Window;
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown1.Location = new System.Drawing.Point(193, 88);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.ReadOnly = true;
            this.numericUpDown1.Size = new System.Drawing.Size(85, 25);
            this.numericUpDown1.TabIndex = 15;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(72, 128);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(206, 34);
            this.button2.TabIndex = 16;
            this.button2.Text = "Hozzáad";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(72, 264);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(206, 60);
            this.button3.TabIndex = 19;
            this.button3.Text = "Létrehozás";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // nemPasszolTableAdapter1
            // 
            this.nemPasszolTableAdapter1.ClearBeforeFill = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(210, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 22);
            this.label9.TabIndex = 20;
            this.label9.Text = "Darab";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Location = new System.Drawing.Point(73, 168);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(205, 80);
            this.listBox1.TabIndex = 21;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.comboBox3);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Location = new System.Drawing.Point(263, 67);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(340, 406);
            this.panel1.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(880, 508);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgv1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Ágyástervező";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.növényekBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.BindingSource novenyekAdatbazisDataSetBindingSource;
        private NovenyekAdatbazisDataSet novenyekAdatbazisDataSet;
        private System.Windows.Forms.BindingSource növényekBindingSource;
        private NovenyekAdatbazisDataSetTableAdapters.NövényekTableAdapter növényekTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn azonosítóDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fajHUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fajtaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sortávDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tőtávDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private NovenyekAdatbazisDataSetTableAdapters.NemPasszolTableAdapter nemPasszolTableAdapter1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel1;
    }
}

