﻿namespace ulteto
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.novenyekAdatbazisDataSet1 = new ulteto.NovenyekAdatbazisDataSet();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.novenyekAdatbazisDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.növényekBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.növényekTableAdapter = new ulteto.NovenyekAdatbazisDataSetTableAdapters.NövényekTableAdapter();
            this.azonosítóDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fajHUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fajtaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sortávDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tőtávDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.növényekBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // novenyekAdatbazisDataSet1
            // 
            this.novenyekAdatbazisDataSet1.DataSetName = "NovenyekAdatbazisDataSet";
            this.novenyekAdatbazisDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.azonosítóDataGridViewTextBoxColumn,
            this.fajHUDataGridViewTextBoxColumn,
            this.fajtaDataGridViewTextBoxColumn,
            this.sortávDataGridViewTextBoxColumn,
            this.tőtávDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.növényekBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(22, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(543, 427);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // novenyekAdatbazisDataSet1BindingSource
            // 
            this.novenyekAdatbazisDataSet1BindingSource.DataSource = this.novenyekAdatbazisDataSet1;
            this.novenyekAdatbazisDataSet1BindingSource.Position = 0;
            // 
            // növényekBindingSource
            // 
            this.növényekBindingSource.DataMember = "Növények";
            this.növényekBindingSource.DataSource = this.novenyekAdatbazisDataSet1BindingSource;
            // 
            // növényekTableAdapter
            // 
            this.növényekTableAdapter.ClearBeforeFill = true;
            // 
            // azonosítóDataGridViewTextBoxColumn
            // 
            this.azonosítóDataGridViewTextBoxColumn.DataPropertyName = "Azonosító";
            this.azonosítóDataGridViewTextBoxColumn.HeaderText = "Azonosító";
            this.azonosítóDataGridViewTextBoxColumn.Name = "azonosítóDataGridViewTextBoxColumn";
            // 
            // fajHUDataGridViewTextBoxColumn
            // 
            this.fajHUDataGridViewTextBoxColumn.DataPropertyName = "Faj HU";
            this.fajHUDataGridViewTextBoxColumn.HeaderText = "Faj HU";
            this.fajHUDataGridViewTextBoxColumn.Name = "fajHUDataGridViewTextBoxColumn";
            // 
            // fajtaDataGridViewTextBoxColumn
            // 
            this.fajtaDataGridViewTextBoxColumn.DataPropertyName = "Fajta";
            this.fajtaDataGridViewTextBoxColumn.HeaderText = "Fajta";
            this.fajtaDataGridViewTextBoxColumn.Name = "fajtaDataGridViewTextBoxColumn";
            // 
            // sortávDataGridViewTextBoxColumn
            // 
            this.sortávDataGridViewTextBoxColumn.DataPropertyName = "Sortáv";
            this.sortávDataGridViewTextBoxColumn.HeaderText = "Sortáv";
            this.sortávDataGridViewTextBoxColumn.Name = "sortávDataGridViewTextBoxColumn";
            // 
            // tőtávDataGridViewTextBoxColumn
            // 
            this.tőtávDataGridViewTextBoxColumn.DataPropertyName = "Tőtáv";
            this.tőtávDataGridViewTextBoxColumn.HeaderText = "Tőtáv";
            this.tőtávDataGridViewTextBoxColumn.Name = "tőtávDataGridViewTextBoxColumn";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(108, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(594, 530);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(232, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Táblázat";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(826, 570);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form4";
            this.Text = "Ágyástervező";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenyekAdatbazisDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.növényekBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private NovenyekAdatbazisDataSet novenyekAdatbazisDataSet1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource novenyekAdatbazisDataSet1BindingSource;
        private System.Windows.Forms.BindingSource növényekBindingSource;
        private NovenyekAdatbazisDataSetTableAdapters.NövényekTableAdapter növényekTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn azonosítóDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fajHUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fajtaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sortávDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tőtávDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}