﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ulteto
{
    public partial class Form4 : Form
    {
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\david\\Desktop\\ulteto\\ulteto\\bin\\Debug\\NovenyekAdatbazis.accdb;Persist Security Info=False;";

        public Form4()
        {
            InitializeComponent();
            this.Size = new Size(842, 609); // Példaként 600x400-as méretet adtunk meg
            this.StartPosition = FormStartPosition.CenterScreen; // Az ablak középre helyezése a képernyőn
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Fix méret beállítása, nem lehet változtatni az ablak méretén
            this.MaximizeBox = false; // A maximalizálás tiltása
            this.MinimizeBox = false; // A minimalizálás tiltása
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'novenyekAdatbazisDataSet1.Növények' table. You can move, or remove it, as needed.
            this.növényekTableAdapter.Fill(this.novenyekAdatbazisDataSet1.Növények);

            SetGlassEffect(panel1);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SetGlassEffect(Panel panel)
        {
            panel.BackColor = Color.Transparent;
            panel.Paint += (sender, e) =>
            {
                using (GraphicsPath path = RoundedRectangle(panel.ClientRectangle, 10)) // A 10 a kerekítés mértéke, ezt igény szerint módosíthatod
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(150, Color.White)))
                {
                    e.Graphics.FillPath(brush, path);
                }
            };
        }

        private GraphicsPath RoundedRectangle(Rectangle rectangle, int radius)
        {
            int diameter = radius * 2;
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(rectangle.Location, size);
            GraphicsPath path = new GraphicsPath();

            // Felső bal sarok
            path.AddArc(arc, 180, 90);

            // Felső jobb sarok
            arc.X = rectangle.Right - diameter;
            path.AddArc(arc, 270, 90);

            // Alsó jobb sarok
            arc.Y = rectangle.Bottom - diameter;
            path.AddArc(arc, 0, 90);

            // Alsó bal sarok
            arc.X = rectangle.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }
    }
}
