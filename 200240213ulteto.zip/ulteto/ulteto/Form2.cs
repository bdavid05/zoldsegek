﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ulteto
{
    public partial class Form2 : Form
    {
        private bool buttonClicked = false;
        private List<string> savedData;
        private List<string> selectedVegetables;

        public Form2(List<string> savedData)
        {
            InitializeComponent();
            this.selectedVegetables = savedData;

            // Ablak méretének beállítása
            this.Size = new Size(1698, 971); // Példaként 600x400-as méretet adtunk meg
            this.StartPosition = FormStartPosition.CenterScreen; // Az ablak középre helyezése a képernyőn
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Fix méret beállítása, nem lehet változtatni az ablak méretén
            this.MaximizeBox = false; // A maximalizálás tiltása
            this.MinimizeBox = false; // A minimalizálás tiltása
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            numericUpDown1.Minimum = 1;
            numericUpDown1.Maximum = 3;

            // Listbox feltöltése az első és utolsó karakterekkel
            foreach (string vegetable in selectedVegetables)
            {
                string firstAndLastLetters = $"{vegetable[0]}{vegetable[vegetable.Length - 1]}";
                listBox1.Items.Add(firstAndLastLetters);
            }

            SetGlassEffect(panel2); // Glass effect hozzáadása a panelhez

            // Button1 színe beállítása
            SetButtonColor(button1, "#99c632");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (buttonClicked)
            {
                MessageBox.Show("Az ágyás létre van hozva!");
                return;
            }

            int numberOfBeds = (int)numericUpDown1.Value;

            if (numberOfBeds <= 0)
            {
                MessageBox.Show("Adjon meg érvényes ágyás számot!");
                return;
            }

            int xpos = int.Parse(comboBox1.Text);
            int ypos = int.Parse(comboBox2.Text);

            int x = 40;
            int y = 228 + (int)(2 * CreateGraphics().DpiY / 2.54f); // 2 cm-el lejjebb

            int index = 0; // index változó hozzáadása a listBox1 elemek ciklusban történő felhasználásához

            for (int i = 0; i < numberOfBeds; i++)
            {
                Panel panel = new Panel();
                panel.Size = new Size(xpos, ypos);
                panel.BackColor = Color.FloralWhite;

                // Panel Paint eseményéhez eseménykezelő hozzáadása
                panel.Paint += (s, pe) =>
                {
                    Graphics g = pe.Graphics;
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                    int circleRadius = 10; // Kör sugara
                    int circleSpacing = 5; // Körök közötti távolság

                    // Kicsi barna körök elhelyezése a fekete panelen belül
                    for (int row = 0; row < ypos / (circleRadius * 2 + circleSpacing); row++)
                    {
                        bool drawCircle = false; // minden sorban az első kör legyen kirajzolva
                        for (int col = 0; col < xpos / (circleRadius * 2 + circleSpacing); col++)
                        {
                            if (drawCircle)
                            {
                                int circleX = col * (circleRadius * 2 + circleSpacing) + circleSpacing;
                                int circleY = row * (circleRadius * 2 + circleSpacing) + circleSpacing;

                                g.FillEllipse(Brushes.Brown, circleX, circleY, circleRadius * 2, circleRadius * 2);

                                // Betűk hozzáadása a körökhöz
                                if (index < listBox1.Items.Count) // ellenőrizzük, hogy a listából még van-e elem
                                {
                                    string letter = listBox1.Items[index].ToString(); // a listBox1 elemek index alapján történő kinyerése
                                    g.DrawString(letter, DefaultFont, Brushes.White, circleX + circleRadius - 5, circleY + circleRadius - 7);
                                    index++; // növeljük az indexet a következő elemre való lépéshez
                                }
                            }
                            drawCircle = !drawCircle; // minden második körnek legyen kirajzolva
                        }
                    }
                };

                panel.Location = new Point(x, y);

                this.Controls.Add(panel);

                x += xpos + 50;
            }

            buttonClicked = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void SetGlassEffect(Panel panel)
        {
            panel.BackColor = Color.Transparent;
            panel.Paint += (sender, e) =>
            {
                using (GraphicsPath path = RoundedRectangle(panel.ClientRectangle, 10)) // A 10 a kerekítés mértéke, ezt igény szerint módosíthatod
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(150, Color.White)))
                {
                    e.Graphics.FillPath(brush, path);
                }
            };
        }

        private void SetButtonColor(Button button, string hexColor)
        {
            Color color = ColorTranslator.FromHtml(hexColor);
            button.BackColor = color;
        }

        private GraphicsPath RoundedRectangle(Rectangle rectangle, int radius)
        {
            int diameter = radius * 2;
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(rectangle.Location, size);
            GraphicsPath path = new GraphicsPath();

            // Felső bal sarok
            path.AddArc(arc, 180, 90);

            // Felső jobb sarok
            arc.X = rectangle.Right - diameter;
            path.AddArc(arc, 270, 90);

            // Alsó jobb sarok
            arc.Y = rectangle.Bottom - diameter;
            path.AddArc(arc, 0, 90);

            // Alsó bal sarok
            arc.X = rectangle.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }
    }
}
